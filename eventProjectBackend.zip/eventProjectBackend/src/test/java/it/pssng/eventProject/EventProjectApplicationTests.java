package it.pssng.eventProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
