package it.pssng.eventProject.services.dataTransfer;

public class LocationService {

}
