package it.pssng.eventProject.dto;

import lombok.Data;

@Data
public class TicketDTO {
    private String userID;
    private Long eventID;
}
