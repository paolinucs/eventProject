package it.pssng.eventProject.dto;

import lombok.Data;

@Data
public class TicketSupport {
    String userRealName;
    String userRealSurname;
    String userEmail;
    String ticketDescription;
}
