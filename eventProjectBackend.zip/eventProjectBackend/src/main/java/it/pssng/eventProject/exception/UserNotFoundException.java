package it.pssng.eventProject.exception;

public class UserNotFoundException extends Exception {
    
    public UserNotFoundException(){
        super();
    }

}
