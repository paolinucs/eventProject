package it.pssng.eventProject.dto;

import lombok.Data;

@Data
public class UserDTO {
    private String fiscalCode;
    private String password;
}
