package it.pssng.eventProject.exception;

public class DataNotCorrectlyPassedException extends Exception {

    public DataNotCorrectlyPassedException() {
        super();
    }

}
