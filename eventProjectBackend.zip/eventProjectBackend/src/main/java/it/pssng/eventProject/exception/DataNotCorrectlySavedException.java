package it.pssng.eventProject.exception;

public class DataNotCorrectlySavedException extends Exception {

    public DataNotCorrectlySavedException() {
        super();
    }

}
