package it.pssng.eventProject.exception;

public class EventNotFoundException extends Exception {

    public EventNotFoundException() {
        super();
    }

}
